<?php
namespace app\index\controller;
use app\service\Elasticsearch;
use think\Db;
use PDO;

class Index
{
    public function index()
    {
		$this->Getdata(1,1);
		
		// $client = new Elasticsearch;
		
		// $res = $client->dbsearch('db_zhuce_v3','zhuce')->limit('0,20')->select();
		// print_r($res);
		// exit;
		/*
    	$workers = [];
		$worker_num = 3;//创建的进程数

		for($i=0;$i<$worker_num ; $i++){
		    $process = new swoole_process(function(swoole_process $process){
			    $process->write($process->pid);
			    echo $process->pid,"\t",$process->callback .PHP_EOL;
		    });
		    $pid = $process->start();
		    $workers[$pid] = $process;
		}

		foreach($workers as $process){
		    //子进程也会包含此事件
		    swoole_event_add($process->pipe, function ($pipe) use($process){
		    $data = $process->read();
		        echo "RECV: " . $data.PHP_EOL;
		    });
		}
		*/
		
		// $client = ClientBuilder::create()->build();
		// $res = $client->dbsearch('epyp')->order('me_uid desc')->limit('0,20');
		// $res = $client->dbsearch('epyp')->order('me_banben desc,me_uid desc')->limit('0,20')->select();
		
		// $res = $client->dbsearch('epyp',39);
		// print_r($res);
		// exit;
		// $datalist = DB('epyp')->where(array('me_uid'=>array('gt',268)))->select();
		// foreach($datalist as $value){
			// $value['me_date'] = '2016-12-06';
			// $params = [
			// 'index' => 'db',
			// 'type' => 'epyp',
			// 'id' => $value['me_uid'],
			// 'body' => $value
			// ];
			// $client->add($params);
		// }
    }
	
	
	public function Getdata($page,$pageNum){
		$client = new Elasticsearch;
		$conn = Db::connect([
			// 数据库类型
			'type'            => 'mysql',
			// 服务器地址
			'hostname'        => '114.55.238.18',
			// 数据库名
			'database'        => 'db',
			// 用户名
			'username'        => 'sqluser',
			// 密码
			'password'        => 'kangzhou008',
			// 端口
			'hostport'        => '',
			// 连接dsn
			'dsn'             => '',
			// 数据库连接参数
			'params'          => [],
			// 数据库编码默认采用utf8
			'charset'         => 'utf8',
			// 数据库表前缀
			'prefix'          => 'be_',
			// 数据库调试模式
			'debug'           => true,
			// 数据库部署方式:0 集中式(单一服务器),1 分布式(主从服务器)
			'deploy'          => 0,
			// 数据库读写是否分离 主从式有效
			'rw_separate'     => false,
			// 读写分离后 主服务器数量
			'master_num'      => 1,
			// 指定从服务器序号
			'slave_no'        => '',
			// 是否严格检查字段是否存在
			'fields_strict'   => true,
			// 数据集返回类型
			'resultset_type'  => 'array',
			// 自动写入时间戳字段
			'auto_timestamp'  => false,
			// 时间字段取出后的默认时间格式
			'datetime_format' => 'Y-m-d H:i:s',
			// 是否需要进行SQL性能分析
			'sql_explain'     => false,
		]);
		
		// 基本sql
		$sql = 'SELECT
			zhuce.me_uid,
			zhuce.me_name,
			zhuce.me_shoulihao,
			zhuce.me_yaopinleixing_1,
			zhuce.me_zhuceleixing,
			zhuce.me_shenqingleixing_1,
			zhuce.me_chenbanriqi,
			zhuce.me_cde_qiyemingcheng,
			zhuce.me_banlizhuangtai,
			zhuce.me_zhuangtaikaishishijian,
			zhuce.me_atc,
			zhuce.me_yaopinpizhunwenhao,
			zhuce.me_gupiaodaima,
			zhuce.me_guifanjixing,
			zhuce.me_yxsp,
			zhuce.me_shoufeiqingkuang,
			zhuce.me_feiyongdaozhiri,
			zhuce.me_jianyanbaogaoshoudaori,
			zhuce.me_biaozhunpinhuizhishoudaori,
			zhuce.me_tongzhishijian,
			zhuce.me_tongzhineirong,
			zhuce.me_zdzx,
			zhuce.me_remarks,
			zhuce.me_zwylbm,
			zhuce.me_ylbm,
			zhuce.me_tspz,
			zhuce.me_bianma
		FROM
			be_zhuce AS zhuce';

		// 查询总数 169140/1692
		$qcount = $conn->query("SELECT MAX(`me_uid`) as count FROM `be_zhuce`");
		// 根据id分页写入ES
		$total = $qcount[0]['count'];
		$pageSize = 100;
		if ($pageNum>1695) {
			$pageNum = 1695;
		}
		// $page = 376;
		// $pageNum = 400;
		// $pageNum = ceil($total/$pageSize);
		// var_dump($pageNum);exit();
		for ($page; $page <= $pageNum; $page++) {
			$start = ($page-1)*$pageSize+1;
			$end = $start+$pageSize-1;
			if ($end>=$total) $end = $total;
			// $start = 37498;
			// $end = 37498;
			// 37401-37500
			$logStr = "pagenum:page[$pageNum:::$page] ==> ".$start.'-'.$end.PHP_EOL;
			// echo $start.'-'.$end.PHP_EOL;
			// $filePath = "./page.txt";
			// $file = fopen($filePath,"a"); 
			// fwrite($file, $logStr);
			// fclose($file);
			// continue;
			// exit();
			 //    exec('pause');
			 //    exit();
			// $res = $conn->query($sql.' WHERE zhuce.me_uid BETWEEN '.$start.' AND '.$end);
			$res = $conn->query($sql.' WHERE zhuce.me_shoulihao="CYHB1701823"');
			$body = [];
			$body = ['body' => []];
			$joinconfig = array(
				//'0'为特殊情况测试用例
				// '0'=>array(
					// '目标表名'=>'be_ss_jielun',
					// '目标字段名'=>'me_shoulihao',
					// '显示字段名'=>'me_jielun,me_shoulihao',
					// 'child'=>array(
						// '目标表名'=>'be_ss_buchong',
						// '目标字段名'=>'me_shoulihao',
						// '显示字段名'=>'me_pingshenzhuangtai,me_shenpingbumen,me_shoulihao',
						// 'special'=>'normal',
						// 'child'=>array(
							// '目标表名'=>'be_ss_shouliriqi',
							// '目标字段名'=>'me_shoulihao',
							// '显示字段名'=>'me_shouliriqi,me_shoulihao',
							// 'special'=>'',
						// ),
					// ),
					// 'special'=>'normal'),
				'0'=>array(
					'目标表名'=>'be_ss_ctd',
					'目标字段名'=>'me_shoulihao',
					'显示字段名'=>'count(*)',
					'special'=>'judge'),
				'1'=>array(
					'目标表名'=>'be_songda',
					'目标字段名'=>'me_shoulihao',
					'显示字段名'=>'me_songda',
					'special'=>'normal'),
				'2'=>array(
					'目标表名'=>'zhuce3he1',
					'目标字段名'=>'me_shoulihao',
					'显示字段名'=>'dfd',
					'special'=>'zhuce3he1'),
				'3'=>array(
					'目标表名'=>'be_ss_xinbao',
					'目标字段名'=>'me_shoulihao',
					'显示字段'=>'me_shoulihao',
					'special'=>'xinbaohandle'),
				'4'=>array(
					'目标表名'=>'be_ss_xinbaoolddata',
					'目标字段名'=>'me_shoulihao',
					'显示字段'=>'me_shoulihao',
					'special'=>'xinbaoolddatahandle'),
				'5'=>array(
					'目标表名'=>'be_ss_buchong',
					'目标字段名'=>'me_shoulihao',
					'显示字段'=>'me_shoulihao',
					'special'=>'buchonghandle'),
				'6'=>array(
					'目标表名'=>'be_ss_buchongolddata',
					'目标字段名'=>'me_shoulihao',
					'显示字段'=>'me_shoulihao',
					'special'=>'buchongolddatahandle'),
							
				'8'=>array(
					'目标表名'=>'be_ss_buchongolddata',
					'目标字段名'=>'me_shoulihao',
					'显示字段'=>'me_shoulihao',
					'special'=>'buchongolddatahandle'),				
				'9'=>array(
					'目标表名'=>'be_ss_buchongolddata',
					'目标字段名'=>'me_shoulihao',
					'显示字段'=>'me_shoulihao',
					'special'=>'buchongolddatahandle'),				
				'10'=>array(
					'目标表名'=>'be_ss_buchongolddata',
					'目标字段名'=>'me_shoulihao',
					'显示字段'=>'me_shoulihao',
					'special'=>'buchongolddatahandle'),				
				'11'=>array(
					'目标表名'=>'be_ss_buchongolddata',
					'目标字段名'=>'me_shoulihao',
					'显示字段'=>'me_shoulihao',
					'special'=>'buchongolddatahandle'),				
				'12'=>array(
					'目标表名'=>'be_ss_buchongolddata',
					'目标字段名'=>'me_shoulihao',
					'显示字段'=>'me_shoulihao',
					'special'=>'buchongolddatahandle'),				
				'13'=>array(
					'目标表名'=>'be_ss_buchongolddata',
					'目标字段名'=>'me_shoulihao',
					'显示字段'=>'me_shoulihao',
					'special'=>'buchongolddatahandle'),
			);
			
			
			foreach ($res as $key => $value) {
				$body['body'][] = [
					'index' => [
						'_index' => 'db_zhuce_v3',
						'_type' => 'zhuce',
						'_id' => $value['me_uid']
					]
				];
				
				foreach($joinconfig as $joininfo){
					if(!empty($joininfo['special'])){
						if(method_exists($this,$joininfo['special'])){
							$value[$joininfo['目标表名']] = $this->$joininfo['special']($joininfo,$value);
						} 
					}
				}
				$me_shoulihao = $value['me_shoulihao'];
				$value['me_linchuangshengchan'] = $me_shoulihao?mb_substr($me_shoulihao, 4,1):'';
				print_r($value);
				exit;

				/*
				// ===================== 数据调整 ================
				$me_shoulihao = $value['me_shoulihao'];
				// $me_shoulihao = 'JXHS1400100';
				// $me_shoulihao = 'CXHS0800143';
				// $me_shoulihao = 'Y0416730';
				// $me_shoulihao = 'CXFL1100006';
				// 报临床/生产
				$value['me_linchuangshengchan'] = $me_shoulihao?mb_substr($me_shoulihao, 4,1):'';
				// 是否CTD
				$zhucectd = $conn->query('SELECT count(*) from be_ss_ctd where me_shoulihao="'.$me_shoulihao.'"')->fetch(PDO::FETCH_NUM);
				$value['isctd'] = $zhucectd[0]>0?'是':'否';
				// 送达
				$songda = @$conn->query('SELECT me_songda from be_songda where me_shoulihao="'.$me_shoulihao.'"')->fetchAll(PDO::FETCH_ASSOC);
				$value['songda'] = $songda;
				// CDE新报资料审评情况
				$data_xinbao = $conn->query("(SELECT *,'xinbao' AS 'table' FROM be_ss_xinbao where me_shoulihao='".$me_shoulihao."' AND regtime != '') UNION ALL (SELECT *,'xinbaoolddata' AS 'table' FROM be_ss_xinbaoolddata where me_shoulihao='".$me_shoulihao."' AND regtime != '' GROUP BY regtime) ORDER BY regtime ASC")->fetchAll(PDO::FETCH_ASSOC);
				if ($data_xinbao) {
					foreach ($data_xinbao as $k => $v) {
						if ($v['me_intodate']) {
							$datetmp = date_create($v['me_intodate']);
							$tmp_intodate = @date_format($datetmp,'Y-m-d H:i:s');
							if ($tmp_intodate) {
								$data_xinbao[$k]['me_intodate'] = $tmp_intodate;
							}else{
								$data_xinbao[$k]['me_intodate'] = '';
							}
						}
						if ($v['regtime']) {
							$datetmp = date_create($v['regtime']);
							$data_xinbao[$k]['regtime'] = date_format($datetmp,'Y-m-d H:i:s');
						}
					}        
				}
				// 注册生产现场检查--公告
				$value['gonggao'] = $conn->query('SELECT me_jianchariqi,me_jianchayuan,me_jingbanren,me_shouliriqi from be_zc_nyxcjc where me_shoulihao="'.$me_shoulihao.'"')->fetchAll(PDO::FETCH_ASSOC);
				// 注册生产现场检查--进度
				$value['jindu'] = $conn->query('SELECT me_shouliriqi,me_cdeshijian,me_jindu from be_zc_xcjc where me_shoulihao="'.$me_shoulihao.'"')->fetchAll(PDO::FETCH_ASSOC);
				// 临床试验登记号
				$value['dengjihao'] = $conn->query('SELECT me_dengjihao from be_zhucedengjihao where me_shoulihao="'.$me_shoulihao.'"')->fetchAll(PDO::FETCH_ASSOC);
				// 结论
				$value['jielun'] = @$conn->query('SELECT me_jielun from be_ss_jielun where me_shoulihao="'.$me_shoulihao.'"')->fetchAll(PDO::FETCH_ASSOC);
				// 结论详情
				$value['jielunxiangqing'] = $conn->query('SELECT me_jielunxiangqing from be_jielunxiangxi where me_shoulihao="'.$me_shoulihao.'"')->fetchAll(PDO::FETCH_ASSOC);
				// ======== 时光轴 ============//
				// 受理日期
				$value['shouliriqi'] = $conn->query('SELECT me_shouliriqi from be_ss_shouliriqi where me_shoulihao="'.$me_shoulihao.'"')->fetchAll(PDO::FETCH_ASSOC);
				// atc
				$atc = $conn->query("SELECT * FROM be_atc  where me_num='".$value['me_atc']."'")->fetchAll(PDO::FETCH_ASSOC);
				if ($atc) {
					foreach ($atc as $k => $v) {
						if ($v['regtime']) {
							$atc[$k]['regtime'] = date('Y-m-d H:i:s',$v['regtime']);
						}
					}
				}
				$value['atc'] = $atc;
				// bianma_zong
				$bianma_zong = $conn->query("SELECT * FROM be_bianma_zong  where me_bianma='".$value['me_bianma']."'")->fetchAll(PDO::FETCH_ASSOC);
				$value['bianma_zong'] = $bianma_zong;

				// var_dump($value['shouliriqi']);exit();
				// var_dump($value);
				// exit();
				$body['body'][] = $value;
				// var_dump($body);exit();
				*/
			}
			exit;
			if (!empty($body['body'])) {
				$responses = $client->bulk($body);
				if ($responses['errors']==true) {
					// var_dump($responses);exit();
					// 错误的时候写入错误文件
					foreach ($responses['items'] as $key => $value) {
						if ($value['index']['status']==400) {
							$errorLog = json_encode($responses);
							$logPath = "./errorLog.txt";
							$errorfile = fopen($logPath, 'a');
							fwrite($errorfile, $errorLog);
							fclose($errorfile);
							exit();
						}
					}
					echo "************** error **************";
					// exit();
				}
				echo "The num $pageNum===$page :: $start--$end success .".PHP_EOL;
			}
			// exit();
		}
		echo "$page all over .";
		unset($client,$conn,$page,$pageNum);
		exit();
	}

	
	public function xinbaohandle($joinconfig,$info){
		$conn = Db::connect([
			// 数据库类型
			'type'            => 'mysql',
			// 服务器地址
			'hostname'        => '114.55.238.18',
			// 数据库名
			'database'        => 'db',
			// 用户名
			'username'        => 'sqluser',
			// 密码
			'password'        => 'kangzhou008',
			// 端口
			'hostport'        => '',
			// 连接dsn
			'dsn'             => '',
			// 数据库连接参数
			'params'          => [],
			// 数据库编码默认采用utf8
			'charset'         => 'utf8',
			// 数据库表前缀
			'prefix'          => 'be_',
			// 数据库调试模式
			'debug'           => true,
			// 数据库部署方式:0 集中式(单一服务器),1 分布式(主从服务器)
			'deploy'          => 0,
			// 数据库读写是否分离 主从式有效
			'rw_separate'     => false,
			// 读写分离后 主服务器数量
			'master_num'      => 1,
			// 指定从服务器序号
			'slave_no'        => '',
			// 是否严格检查字段是否存在
			'fields_strict'   => true,
			// 数据集返回类型
			'resultset_type'  => 'array',
			// 自动写入时间戳字段
			'auto_timestamp'  => false,
			// 时间字段取出后的默认时间格式
			'datetime_format' => 'Y-m-d H:i:s',
			// 是否需要进行SQL性能分析
			'sql_explain'     => false,
		]);
		// CDE新报资料审评情况
		$data_xinbao = $conn->query("(SELECT *,'xinbao' AS 'table' FROM be_ss_xinbao where me_shoulihao='".$info[$joinconfig['目标字段名']]."' AND regtime != '') UNION ALL (SELECT *,'xinbaoolddata' AS 'table' FROM be_ss_xinbaoolddata where me_shoulihao='".$info[$joinconfig['目标字段名']]."' AND regtime != '' GROUP BY regtime) ORDER BY regtime ASC");
		if ($data_xinbao) {
			foreach ($data_xinbao as $k => $v) {
				if ($v['me_intodate']) {
					$datetmp = date_create($v['me_intodate']);
					$tmp_intodate = @date_format($datetmp,'Y-m-d H:i:s');
					if ($tmp_intodate) {
						$data_xinbao[$k]['me_intodate'] = $tmp_intodate;
					}else{
						$data_xinbao[$k]['me_intodate'] = '';
					}
				}
				if ($v['regtime']) {
					$datetmp = date_create($v['regtime']);
					$data_xinbao[$k]['regtime'] = date_format($datetmp,'Y-m-d H:i:s');
				}
			}        
		}
		return $data_xinbao;
	}

	// 新报olddata
	public function xinbaoolddatahandle($joinconfig,$info){
		$conn = Db::connect([
			// 数据库类型
			'type'            => 'mysql',
			// 服务器地址
			'hostname'        => '114.55.238.18',
			// 数据库名
			'database'        => 'db',
			// 用户名
			'username'        => 'sqluser',
			// 密码
			'password'        => 'kangzhou008',
			// 端口
			'hostport'        => '',
			// 连接dsn
			'dsn'             => '',
			// 数据库连接参数
			'params'          => [],
			// 数据库编码默认采用utf8
			'charset'         => 'utf8',
			// 数据库表前缀
			'prefix'          => 'be_',
			// 数据库调试模式
			'debug'           => true,
			// 数据库部署方式:0 集中式(单一服务器),1 分布式(主从服务器)
			'deploy'          => 0,
			// 数据库读写是否分离 主从式有效
			'rw_separate'     => false,
			// 读写分离后 主服务器数量
			'master_num'      => 1,
			// 指定从服务器序号
			'slave_no'        => '',
			// 是否严格检查字段是否存在
			'fields_strict'   => true,
			// 数据集返回类型
			'resultset_type'  => 'array',
			// 自动写入时间戳字段
			'auto_timestamp'  => false,
			// 时间字段取出后的默认时间格式
			'datetime_format' => 'Y-m-d H:i:s',
			// 是否需要进行SQL性能分析
			'sql_explain'     => false,
		]);
		// 新报olddata
		$data_xinbaoolddata = $conn->query("SELECT *,'xinbaoolddata' AS 'table' FROM be_ss_xinbaoolddata where me_shoulihao='".$info[$joinconfig['目标字段名']]."'");
		if ($data_xinbaoolddata) {
			foreach ($data_xinbaoolddata as $k => $v) {
				if ($v['me_intodate']) {
					$datetmp = date_create($v['me_intodate']);
					$tmp_intodate = @date_format($datetmp,'Y-m-d H:i:s');
					if ($tmp_intodate) {
						$data_xinbaoolddata[$k]['me_intodate'] = $tmp_intodate;
					}else{
						$data_xinbaoolddata[$k]['me_intodate'] = '';
					}
				}
				if ($v['regtime']) {
					$datetmp = date_create($v['regtime']);
					$data_xinbaoolddata[$k]['regtime'] = date_format($datetmp,'Y-m-d H:i:s');
				}
			}
		}
		return $data_xinbaoolddata;
	}
	
	// CDE补充资料审评情况
	public function buchonghandle($joinconfig,$info){
		$conn = Db::connect([
			// 数据库类型
			'type'            => 'mysql',
			// 服务器地址
			'hostname'        => '114.55.238.18',
			// 数据库名
			'database'        => 'db',
			// 用户名
			'username'        => 'sqluser',
			// 密码
			'password'        => 'kangzhou008',
			// 端口
			'hostport'        => '',
			// 连接dsn
			'dsn'             => '',
			// 数据库连接参数
			'params'          => [],
			// 数据库编码默认采用utf8
			'charset'         => 'utf8',
			// 数据库表前缀
			'prefix'          => 'be_',
			// 数据库调试模式
			'debug'           => true,
			// 数据库部署方式:0 集中式(单一服务器),1 分布式(主从服务器)
			'deploy'          => 0,
			// 数据库读写是否分离 主从式有效
			'rw_separate'     => false,
			// 读写分离后 主服务器数量
			'master_num'      => 1,
			// 指定从服务器序号
			'slave_no'        => '',
			// 是否严格检查字段是否存在
			'fields_strict'   => true,
			// 数据集返回类型
			'resultset_type'  => 'array',
			// 自动写入时间戳字段
			'auto_timestamp'  => false,
			// 时间字段取出后的默认时间格式
			'datetime_format' => 'Y-m-d H:i:s',
			// 是否需要进行SQL性能分析
			'sql_explain'     => false,
		]);
		// CDE补充资料审评情况
		$data_buchong = $conn->query("(SELECT me_gongshileibie,me_shengwuleibie,me_shenpingbumen,me_shoulihao,me_intodate,me_pingshenzhuangtai,me_yaoliduli,me_linchuang,me_yaoxue,me_beizhu,me_type,me_xuhao,regtime,'buchong' AS 'table' FROM be_ss_buchong where me_shoulihao='".$info[$joinconfig['目标字段名']]."' AND regtime != 0) 
		UNION ALL (SELECT me_gongshileibie,me_shengwuleibie,me_shenpingbumen,me_shoulihao,me_intodate,me_pingshenzhuangtai,me_yaoliduli,me_linchuang,me_yaoxue,me_beizhu,me_type,me_xuhao,regtime,'buchongolddata' AS 'table' FROM be_ss_buchongolddata where me_shoulihao='".$info[$joinconfig['目标字段名']]."' AND regtime != 0) ORDER BY regtime ASC");
		if ($data_buchong) {
			foreach ($data_buchong as $k => $v) {
				if ($v['me_intodate']) {
					$datetmp = date_create($v['me_intodate']);
					$tmp_intodate = @date_format($datetmp,'Y-m-d H:i:s');
					if ($tmp_intodate) {
						$data_buchong[$k]['me_intodate'] = $tmp_intodate;
					}else{
						$data_buchong[$k]['me_intodate'] = '';
					}
				}
				if ($v['regtime']) {
					$data_buchong[$k]['regtime'] = date('Y-m-d H:i:s',$v['regtime']);
				}
			}
		}
		return $data_buchong;
	}
	
	// 补充olddata
	public function buchongolddatahandle($joinconfig,$info){
		$conn = Db::connect([
			// 数据库类型
			'type'            => 'mysql',
			// 服务器地址
			'hostname'        => '114.55.238.18',
			// 数据库名
			'database'        => 'db',
			// 用户名
			'username'        => 'sqluser',
			// 密码
			'password'        => 'kangzhou008',
			// 端口
			'hostport'        => '',
			// 连接dsn
			'dsn'             => '',
			// 数据库连接参数
			'params'          => [],
			// 数据库编码默认采用utf8
			'charset'         => 'utf8',
			// 数据库表前缀
			'prefix'          => 'be_',
			// 数据库调试模式
			'debug'           => true,
			// 数据库部署方式:0 集中式(单一服务器),1 分布式(主从服务器)
			'deploy'          => 0,
			// 数据库读写是否分离 主从式有效
			'rw_separate'     => false,
			// 读写分离后 主服务器数量
			'master_num'      => 1,
			// 指定从服务器序号
			'slave_no'        => '',
			// 是否严格检查字段是否存在
			'fields_strict'   => true,
			// 数据集返回类型
			'resultset_type'  => 'array',
			// 自动写入时间戳字段
			'auto_timestamp'  => false,
			// 时间字段取出后的默认时间格式
			'datetime_format' => 'Y-m-d H:i:s',
			// 是否需要进行SQL性能分析
			'sql_explain'     => false,
		]);
		// 补充olddata
		$data_buchongolddata = $conn->query("SELECT me_gongshileibie,me_shengwuleibie,me_shenpingbumen,me_shoulihao,me_intodate,me_pingshenzhuangtai,me_yaoliduli,me_linchuang,me_yaoxue,me_beizhu,me_type,me_xuhao,regtime,'buchongolddata' AS 'table' FROM be_ss_buchongolddata where me_shoulihao='".$info[$joinconfig['目标字段名']]."'");
		if ($data_buchongolddata) {
			foreach ($data_buchongolddata as $k => $v) {
				if ($v['me_intodate']) {
					$datetmp = date_create($v['me_intodate']);
					$tmp_intodate = @date_format($datetmp,'Y-m-d H:i:s');
					if ($tmp_intodate) {
						$data_buchongolddata[$k]['me_intodate'] = $tmp_intodate;
					}else{
						$data_buchongolddata[$k]['me_intodate'] = '';
					}
				}
				if ($v['regtime']) {
					$data_buchongolddata[$k]['regtime'] = date('Y-m-d H:i:s',$v['regtime']);
				}
			}
		}
		return $data_buchongolddata;
	}
	
	
	public function normal($joinconfig,$info){
		$conn = Db::connect([
			// 数据库类型
			'type'            => 'mysql',
			// 服务器地址
			'hostname'        => '114.55.238.18',
			// 数据库名
			'database'        => 'db',
			// 用户名
			'username'        => 'sqluser',
			// 密码
			'password'        => 'kangzhou008',
			// 端口
			'hostport'        => '',
			// 连接dsn
			'dsn'             => '',
			// 数据库连接参数
			'params'          => [],
			// 数据库编码默认采用utf8
			'charset'         => 'utf8',
			// 数据库表前缀
			'prefix'          => 'be_',
			// 数据库调试模式
			'debug'           => true,
			// 数据库部署方式:0 集中式(单一服务器),1 分布式(主从服务器)
			'deploy'          => 0,
			// 数据库读写是否分离 主从式有效
			'rw_separate'     => false,
			// 读写分离后 主服务器数量
			'master_num'      => 1,
			// 指定从服务器序号
			'slave_no'        => '',
			// 是否严格检查字段是否存在
			'fields_strict'   => true,
			// 数据集返回类型
			'resultset_type'  => 'array',
			// 自动写入时间戳字段
			'auto_timestamp'  => false,
			// 时间字段取出后的默认时间格式
			'datetime_format' => 'Y-m-d H:i:s',
			// 是否需要进行SQL性能分析
			'sql_explain'     => false,
		]);
		$res_value = isset($res_value) ? $res_value: array();
		// CDE新报资料审评情况
		$res_data = @$conn->query('SELECT '.$joinconfig['显示字段名'].' from '.$joinconfig['目标表名'].' where '.$joinconfig['目标字段名'].'="'.$info[$joinconfig['目标字段名']].'"');
		if ($res_data) {
			foreach($res_data as $key=>$value){
				if(!empty($joinconfig['child'])){
					$value[$joinconfig['child']['目标表名']]=$this->normal($joinconfig['child'],$value);
				}
				$res_value[$key]=$value;
			}
		}
		return $res_value;
	}
	
	//判断是否
	public function judge($joinconfig,$info){
		$conn = Db::connect([
			// 数据库类型
			'type'            => 'mysql',
			// 服务器地址
			'hostname'        => '114.55.238.18',
			// 数据库名
			'database'        => 'db',
			// 用户名
			'username'        => 'sqluser',
			// 密码
			'password'        => 'kangzhou008',
			// 端口
			'hostport'        => '',
			// 连接dsn
			'dsn'             => '',
			// 数据库连接参数
			'params'          => [],
			// 数据库编码默认采用utf8
			'charset'         => 'utf8',
			// 数据库表前缀
			'prefix'          => 'be_',
			// 数据库调试模式
			'debug'           => true,
			// 数据库部署方式:0 集中式(单一服务器),1 分布式(主从服务器)
			'deploy'          => 0,
			// 数据库读写是否分离 主从式有效
			'rw_separate'     => false,
			// 读写分离后 主服务器数量
			'master_num'      => 1,
			// 指定从服务器序号
			'slave_no'        => '',
			// 是否严格检查字段是否存在
			'fields_strict'   => true,
			// 数据集返回类型
			'resultset_type'  => 'array',
			// 自动写入时间戳字段
			'auto_timestamp'  => false,
			// 时间字段取出后的默认时间格式
			'datetime_format' => 'Y-m-d H:i:s',
			// 是否需要进行SQL性能分析
			'sql_explain'     => false,
		]);
		$value = @$conn->query('SELECT '.$joinconfig['显示字段名'].' from '.$joinconfig['目标表名'].' where '.$joinconfig['目标字段名'].'="'.$info[$joinconfig['目标字段名']].'"');
		return $value[0]>0?'是':'否';
	}
	
	public function zhuce3he1($joinconfig,$info){
		$conn = $this->conn();
		// 三合一品种序列
		$res_value = $conn->query('SELECT me_xcjianchajigou,me_xcjianchashijian,me_qiyejianchashijian,me_jieshoushijian,me_zhuangtai,me_beizhu from be_ss_3he1 where me_shoulihao="'.$info[$joinconfig['目标字段名']].'"');
		return $res_value;
	}
	
	
	private function conn(){
		return Db::connect([
			// 数据库类型
			'type'            => 'mysql',
			// 服务器地址
			'hostname'        => '114.55.238.18',
			// 数据库名
			'database'        => 'db',
			// 用户名
			'username'        => 'sqluser',
			// 密码
			'password'        => 'kangzhou008',
			// 端口
			'hostport'        => '',
			// 连接dsn
			'dsn'             => '',
			// 数据库连接参数
			'params'          => [],
			// 数据库编码默认采用utf8
			'charset'         => 'utf8',
			// 数据库表前缀
			'prefix'          => 'be_',
			// 数据库调试模式
			'debug'           => true,
			// 数据库部署方式:0 集中式(单一服务器),1 分布式(主从服务器)
			'deploy'          => 0,
			// 数据库读写是否分离 主从式有效
			'rw_separate'     => false,
			// 读写分离后 主服务器数量
			'master_num'      => 1,
			// 指定从服务器序号
			'slave_no'        => '',
			// 是否严格检查字段是否存在
			'fields_strict'   => true,
			// 数据集返回类型
			'resultset_type'  => 'array',
			// 自动写入时间戳字段
			'auto_timestamp'  => false,
			// 时间字段取出后的默认时间格式
			'datetime_format' => 'Y-m-d H:i:s',
			// 是否需要进行SQL性能分析
			'sql_explain'     => false,
		]);
	}
}
