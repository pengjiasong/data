<?php
namespace app\service;
use Elasticsearch\ClientBuilder;

class Elasticsearch{
	public  $client; //ClientBuilder
	private $index; //索引名称
	private $type; //类型名称  
	
	public $msg;  //返回提示消息
	private $query; //最终执行语句
	public $total;
	
	//readme 如果没有数据，先要创建index，再调用create方法，再调用add方法添加
	
    /**
     * 构造方法
     * @access public
     * @param array|object $data 数据
     */
    public function __construct()
    {
		//http://192.168.1.38:5601
		$hosts = [
			'http://192.168.1.38:9200'        // SSL to localhost
			//'ESHosts'
		];
		$this->client = ClientBuilder::create()           // Instantiate a new ClientBuilder
                    ->setHosts($hosts)      // Set the hosts
                    ->build();              // Build the client object
	}
	
	//设置索引名称
	public function setIndex($index){
		$this->index = $index;
	}
	
	//设置类型名称 
	public function setType($type){
		$this->type = $type;
	}
	
	//设置类型名称 
	public function setSize($size){
		$this->size = $size;
	}
	
    /**
     * dbsearch 数据库查询
     * @access public
     * @param mixed $dbname $id
     * @return array
     */
    public function dbsearch($index,$dbname,$id = 0)
    {
		if(!empty($dbname)){
			$this->index = $index;
			$this->type = $dbname;
			$query= $this->searchconfig(); // 调用查询配置
			if($id>0){
				$query['id'] = $id;
				
				unset($query['size']);
				unset($query['from']);
				// exit;
				$response = $this->client->get($query);
				$res = array();
				if(!empty($response['_source'])){
					$res = $response['_source'];
				}
				return $res;
			}
			$dblistres = DB('dblist')->where('dblist_ename',$dbname)->column('dblist_ss_list');// 获取数据库字段配置
			$searchconfig = unserialize($dblistres[0]);
			$get = input('get.');
			// print_r($searchconfig);
			$inputname = array_column($searchconfig,'inputname');
			//通过查询条件，获取该查询条件的配置项
			foreach($get as $key=>$value){
				if($value===''){
					continue;
				}
				$searchitem = array_search($key , $inputname);
				if(is_int($searchitem)){
					$wheres[] = $this->parseWhere($searchconfig[$searchitem],$value);
				}
			}
			if(!empty($wheres)){
				$query['body']['query']['bool']=array(
				'must'=>array(
						$wheres
						)
				);
			}
			$this->query = $query;
			return $this;
		}else{
			$this->msg = '库名不能为空';
			exit('error');
			return false;
		}
		//localhost/develop.com/public/?human_name=Abraxane&human_status=Authorised
		// $index['body']['query']['bool']=array(
			// 'must'=>array(
					// array('bool'=>array('should'=>array(array('wildcard' => array('address' => '*南京*')),array('wildcard' => array('address' => '*长沙*'))))
					
					// ),
					// array('term' => array('me_uid' => '1086')),  
					// array('term' => array('name' => '张飞')),
					// array('range' => array('age' => array('gte'=>'20','lte'=>'24'))),
					// ),
			// ); 		
    }
	
    /**
     * search elasticsearch原生查询   注意：其实只是原生的查询语句，得到结果需要使用和数据库一样的查询返回方法
     * @access public
     * @param mixed $dbname $id
     * @return array
     */
	public function search($parms=array()){
		$this->query = $parms;
		return $this;
    }
	
    /**
     * select 返回列表 外部访问total
     * @access public
     * @param mixed $select
     * @return array
     */
    public function select(){
		$res = $this->query();
		$sourcearr = array();
		if(!empty($res['hits']['hits'])){
			$sourcearr = array_column($res['hits']['hits'] , '_source');
		}
		$this->total = $res['hits']['total'];
		return $sourcearr;
    }
	
    /**
     * find 返回单条数据
     * @access public
     * @param mixed $select
     * @return array
     */
    public function find(){
		$this->query['from'] = 0;
		$this->query['size'] = 1;
		unset($this->query['body']['sort']); // 锁定查询仅有一条
		$res = $this->query();
		$sourceOne = array();
		if(!empty($res['hits']['hits'])){
			$sourceOne = $res['hits']['hits'][0]['_source'];
		}
		$this->total = $res['hits']['total'];
		return $sourceOne;
    }
	
    /**
     * getField 根据字段获取单数据字符串
     * @access public
     * @param mixed $select
     * @return array
     */
    public function getField($field){
		$sourcestr = '';
		if(!empty($field)){
			$sourceOne = $this->find();
			if(!empty($sourceOne)){
				if(isset($sourceOne[$field])){
					$sourcestr = $sourceOne[$field];
				}else{
					$this->msg = '该字段不存在';
					exit('error');
				}
			}
			
		}
		return $sourcestr;
    }
	
    /**
     * query执行
     * @access public
     * @param mixed $order
     * @return array
     */
    public function query(){
		return $this->client->search($this->query);
    }
	
    /**
     * order分析
     * @access public
     * @param mixed $order
     * @return array
     */
    public function order($order = '') {
		if(!empty($order)){
			$arr = explode(',',$order);
			foreach($arr as $val){
				$parms = explode(' ' , $val);
				$resOrder[trim($parms[0])] = array('order'=>trim($parms[1]));
			}
			$this->query['body']['sort'] = $resOrder;
		}
        return $this;
    }
	
	/**
     * limit分析
     * @access public
     * @param mixed $limit
     * @return array
     */
    public function limit($limit='') {
		if(!empty($limit)){
			$arr = explode(',',$limit);
			if(count($arr)>1){
				$this->query['from'] = $arr[0];
				$this->query['size'] = $arr[1];
			}else{
				$this->query['from'] = 0;
				$this->query['size'] = $arr[1];
			}
		}
        return $this;
    }
	
	/**
     * where分析
     * @access protected
     * @param mixed $where
     * @return array
     */
	protected function parseWhere($dataconfig,$value){
		$where = array();
		if(strstr($dataconfig['zdname'],'|')){
			$zdarray = explode('|',$dataconfig['zdname']);
			foreach($zdarray as $zdname){
				$items[] = array('wildcard'=>array($zdname => '*'.$value.'*'));
			}
			$where = array('bool'=>array('should'=>array($items)));
		}else if($dataconfig['type'] == 'text'){
			$where = array('wildcard' =>array($dataconfig['zdname']=> '*'.$value.'*'));
		}else if($dataconfig['type'] == 'select'){
			$where = array('term' =>array($dataconfig['zdname']=> $value));
		}
		return $where;
	}
	
	//设置配置
	private function searchconfig(){
		if(empty($this->index)){
			$this->msg = '索引名称为空';
			exit('error');
		}
		if(empty($this->type)){
			$this->msg = '类型名称为空';
			exit('error');
		}
		$index['index'] = $this->index; //索引名称  
		$index['type'] = $this->type; //类型名称
		return $index;
	}

	//创建index
	public function create($params){
		// $params = [
			// 'index' => 'my_index',
			// 'body' => [
				// 'settings' => [
					// 'number_of_shards' => 2,
					// 'number_of_replicas' => 0
				// ]
			// ]
		// ];
		$response = $this->client->indices()->create($params);
	}
	
	//创建mapping
	public function putMapping($myTypeMapping){
		$params = array();  
        $params['index'] = $this->index;  
        $params['type'] = $this->type;  
		// $myTypeMapping = 
	// array("properties"=> array(
      // "studentNo"=>array(
        // "type"=> "string",
        // "index"=> "not_analyzed"
      // ),
      // "name"=>array(
        // "type"=> "string",
        // "index"=> "not_analyzed"
      // ),
      // "male"=>array(
        // "type"=> "string",
        // "index"=> "not_analyzed"
      // ),
      // "age"=>array(
        // "type"=> "integer"
      // ),
      // "birthday"=>array(
        // "type"=> "date",
        // "format"=> "yyyy-MM-dd"
      // ),
      // "address"=>array(
        // "type"=> "string",
        // "index"=> "not_analyzed"
      // ),
      // "classNo"=>array(
        // "type"=> "string",
        // "index"=> "not_analyzed"
      // ),
      // "isLeader"=>array(
        // "type"=> "boolean"
      // )
    // )
  // );
		$params['body'][$this->type] = $myTypeMapping;  
		$response = $this->client->indices()->putMapping($params);
	}
	
	//查看mapping
	public function getMapping(){
		$response = $this->client->indices()->getMapping();
		return $response;
	}
	
	
	//插入数据 Index a document
	public function add($params){ 
        // $params = [
			// 'index' => $this->index,
			// 'type' => $this->type,
			// 'id' => 'my_id',
			// 'body' => ['testField' => 'abc']
		// ];
		$response = $this->client->index($params);
	}
	
	//删除数据 
	public function delete($params){ 
		// $params = [
			// 'index' => 'my_index',
			// 'type' => 'my_type',
			// 'id' => 'my_id'
		// ];
		$response = $this->client->indices()->delete($params);
	}
}