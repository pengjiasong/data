<?php
//开启的进程数 

$exec_number = 10 ; 
 
if($argc==1){ 
    echo("argv\n"); 
} 
$taskfile = $argv[1]; 
//tasklist 
$tasklist = file($taskfile);
 
$tasklist_len = count($tasklist); 
$tasklist_pos = 0; 

$handle_list = array(); 
 
 
while(1){ 
         //子进程列表有空闲,则填充补齐子进程列表 
         if($exec_number > count($handle_list) && $tasklist_pos < $tasklist_len) 
         { 
			for($i=$tasklist_pos; $i<$tasklist_len; ) 
			{ 
				$command = $tasklist[$i] ; 
				$handle_list[] = popen($command , "r" ); 
				tolog("begin task \t ".$tasklist[$i]); 
				$i++; 
				if($exec_number == count($handle_list)) break; 
			} 
			$tasklist_pos = $i; 
         } 
 
 
         //如果子进程列表空，退出 
         if(0 == count($handle_list)) 
         { 
            break; 
         } 

         //检查子进程列表的输出，把停掉的子进程关闭并记录下来 
         $end_handle_keys = array(); 
         foreach($handle_list as $key => $handle) 
         { 
			 //$str = fgets($handle, 65536); 
			 $str = fread($handle, 65536); 
			 echo($str); 

			 if(feof($handle)) 
			 { 
				$end_handle_keys[] = $key; 
				pclose($handle); 
			 } 
         } 
 
 
         //踢出停掉的子进程 
         foreach($end_handle_keys as $key) 
         { 
            unset($handle_list[$key]); 
                     //var_dump($handle_list); 
                     //exit; 
         } 
} 


function tolog($str){
	file_put_contents('log.txt',$str,FILE_APPEND);
}
?>