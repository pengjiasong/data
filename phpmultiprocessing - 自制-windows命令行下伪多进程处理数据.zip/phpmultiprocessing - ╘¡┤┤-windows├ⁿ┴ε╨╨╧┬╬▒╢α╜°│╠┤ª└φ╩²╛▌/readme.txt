cli模式下运行  cli_index.php，
里面for循环的数值根据实际情况调节,
初次运行删除command.txt，
里面的语句实则是每个运行的命令，
task里面$exec_number控制进程数，
main.php每个运行处理逻辑主体