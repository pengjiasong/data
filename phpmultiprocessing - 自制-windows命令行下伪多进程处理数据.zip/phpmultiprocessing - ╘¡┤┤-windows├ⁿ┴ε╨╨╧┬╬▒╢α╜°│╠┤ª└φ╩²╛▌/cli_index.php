<?php
if(!file_exists('phpmulti/command.txt')){
	//id最大值  169482;
	for($i=0;$i<169/10+1;$i++){
		file_put_contents('phpmulti/command.txt', 'php phpmulti/main.php '.($i * 10).','.(($i+1) * 10)."\r\n",FILE_APPEND);
	}
}
$handle1 = popen('php phpmulti/task.php phpmulti/command.txt', 'r'); 
while(!feof($handle1)){ 
	$str = fread($handle1, 65536); 
	echo($str);  
} 
pclose($handle1);
?>