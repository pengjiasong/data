<?php
if($argc==1){ 
         echo("argv\n"); 
} 
$arg = $argv[1];     
for($i=0; $i<10; $i++) 
{ 
	echo($i."-----$arg\n");
	if($arg== '10,20'){
		sleep(2);
		echo($i."-----$arg\n"); 
	}else{
		sleep(1);
	}
} 
?>